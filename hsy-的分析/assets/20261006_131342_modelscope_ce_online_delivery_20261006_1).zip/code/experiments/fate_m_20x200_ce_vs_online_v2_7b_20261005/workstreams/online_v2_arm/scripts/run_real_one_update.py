#!/usr/bin/env python3
"""Thin executable wrapper for the pinned real Online-v2 runner."""

from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from alphaproof_online_v2_arm.real_runner import main  # noqa: E402


if __name__ == "__main__":
    raise SystemExit(main())
