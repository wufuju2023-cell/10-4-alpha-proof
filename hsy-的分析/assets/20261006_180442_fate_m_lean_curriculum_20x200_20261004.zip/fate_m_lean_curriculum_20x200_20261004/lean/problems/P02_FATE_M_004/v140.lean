import Mathlib

namespace FateCurriculum

/-- FATE-M #4, curriculum variant 140/200; tier 4: disjunction_elimination. -/
theorem fate_m_004_v140 {G G' : Type*} [Group G] [Group G'] (f : G →* G') {a b : G}
    (curriculum_cases : (((a * b ∈ f.ker)  ↔ (b * a ∈ f.ker)) ∨ ((((414001 : Nat) = 414001) ∧ False) ∨ ((((414002 : Nat) = 414002) ∧ False) ∨ ((((414003 : Nat) = 414003) ∧ False) ∨ ((((414004 : Nat) = 414004) ∧ False) ∨ ((((414005 : Nat) = 414005) ∧ False) ∨ ((((414006 : Nat) = 414006) ∧ False) ∨ ((((414007 : Nat) = 414007) ∧ False) ∨ ((((414008 : Nat) = 414008) ∧ False) ∨ ((((414009 : Nat) = 414009) ∧ False) ∨ ((((414010 : Nat) = 414010) ∧ False) ∨ ((((414011 : Nat) = 414011) ∧ False) ∨ ((((414012 : Nat) = 414012) ∧ False) ∨ ((((414013 : Nat) = 414013) ∧ False) ∨ ((((414014 : Nat) = 414014) ∧ False) ∨ ((((414015 : Nat) = 414015) ∧ False) ∨ ((((414016 : Nat) = 414016) ∧ False) ∨ ((((414017 : Nat) = 414017) ∧ False) ∨ ((((414018 : Nat) = 414018) ∧ False) ∨ ((((414019 : Nat) = 414019) ∧ False) ∨ (((414020 : Nat) = 414020) ∧ False)))))))))))))))))))))) :
    ((a * b ∈ f.ker)  ↔ (b * a ∈ f.ker)) := by
  sorry

end FateCurriculum
