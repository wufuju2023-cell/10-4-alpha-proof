import Mathlib

namespace FateCurriculum

/-- FATE-M #3, curriculum variant 138/200; tier 4: disjunction_elimination. -/
theorem fate_m_003_v138 {G H K : Type*} [Group G] [Group H] [Group K]
    (f : G →* H) (g : H →* K) (hf : Function.Surjective f) (hg : Function.Surjective g)
    (curriculum_cases : ((Function.Surjective (g.comp f)) ∨ ((((413801 : Nat) = 413801) ∧ False) ∨ ((((413802 : Nat) = 413802) ∧ False) ∨ ((((413803 : Nat) = 413803) ∧ False) ∨ ((((413804 : Nat) = 413804) ∧ False) ∨ ((((413805 : Nat) = 413805) ∧ False) ∨ ((((413806 : Nat) = 413806) ∧ False) ∨ ((((413807 : Nat) = 413807) ∧ False) ∨ ((((413808 : Nat) = 413808) ∧ False) ∨ ((((413809 : Nat) = 413809) ∧ False) ∨ ((((413810 : Nat) = 413810) ∧ False) ∨ ((((413811 : Nat) = 413811) ∧ False) ∨ ((((413812 : Nat) = 413812) ∧ False) ∨ ((((413813 : Nat) = 413813) ∧ False) ∨ ((((413814 : Nat) = 413814) ∧ False) ∨ ((((413815 : Nat) = 413815) ∧ False) ∨ ((((413816 : Nat) = 413816) ∧ False) ∨ ((((413817 : Nat) = 413817) ∧ False) ∨ (((413818 : Nat) = 413818) ∧ False)))))))))))))))))))) :
    (Function.Surjective (g.comp f)) := by
  sorry

end FateCurriculum
