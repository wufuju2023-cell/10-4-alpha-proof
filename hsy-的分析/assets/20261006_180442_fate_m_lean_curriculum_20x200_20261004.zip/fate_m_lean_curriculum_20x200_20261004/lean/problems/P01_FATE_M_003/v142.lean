import Mathlib

namespace FateCurriculum

/-- FATE-M #3, curriculum variant 142/200; tier 4: disjunction_elimination. -/
theorem fate_m_003_v142 {G H K : Type*} [Group G] [Group H] [Group K]
    (f : G →* H) (g : H →* K) (hf : Function.Surjective f) (hg : Function.Surjective g)
    (curriculum_cases : ((Function.Surjective (g.comp f)) ∨ ((((414201 : Nat) = 414201) ∧ False) ∨ ((((414202 : Nat) = 414202) ∧ False) ∨ ((((414203 : Nat) = 414203) ∧ False) ∨ ((((414204 : Nat) = 414204) ∧ False) ∨ ((((414205 : Nat) = 414205) ∧ False) ∨ ((((414206 : Nat) = 414206) ∧ False) ∨ ((((414207 : Nat) = 414207) ∧ False) ∨ ((((414208 : Nat) = 414208) ∧ False) ∨ ((((414209 : Nat) = 414209) ∧ False) ∨ ((((414210 : Nat) = 414210) ∧ False) ∨ ((((414211 : Nat) = 414211) ∧ False) ∨ ((((414212 : Nat) = 414212) ∧ False) ∨ ((((414213 : Nat) = 414213) ∧ False) ∨ ((((414214 : Nat) = 414214) ∧ False) ∨ ((((414215 : Nat) = 414215) ∧ False) ∨ ((((414216 : Nat) = 414216) ∧ False) ∨ ((((414217 : Nat) = 414217) ∧ False) ∨ ((((414218 : Nat) = 414218) ∧ False) ∨ ((((414219 : Nat) = 414219) ∧ False) ∨ ((((414220 : Nat) = 414220) ∧ False) ∨ ((((414221 : Nat) = 414221) ∧ False) ∨ (((414222 : Nat) = 414222) ∧ False)))))))))))))))))))))))) :
    (Function.Surjective (g.comp f)) := by
  sorry

end FateCurriculum
