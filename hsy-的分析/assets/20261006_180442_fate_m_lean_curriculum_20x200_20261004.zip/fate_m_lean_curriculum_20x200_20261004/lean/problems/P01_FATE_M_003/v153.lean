import Mathlib

namespace FateCurriculum

/-- FATE-M #3, curriculum variant 153/200; tier 4: disjunction_elimination. -/
theorem fate_m_003_v153 {G H K : Type*} [Group G] [Group H] [Group K]
    (f : G →* H) (g : H →* K) (hf : Function.Surjective f) (hg : Function.Surjective g)
    (curriculum_cases : ((Function.Surjective (g.comp f)) ∨ ((((415301 : Nat) = 415301) ∧ False) ∨ ((((415302 : Nat) = 415302) ∧ False) ∨ ((((415303 : Nat) = 415303) ∧ False) ∨ ((((415304 : Nat) = 415304) ∧ False) ∨ ((((415305 : Nat) = 415305) ∧ False) ∨ ((((415306 : Nat) = 415306) ∧ False) ∨ ((((415307 : Nat) = 415307) ∧ False) ∨ ((((415308 : Nat) = 415308) ∧ False) ∨ ((((415309 : Nat) = 415309) ∧ False) ∨ ((((415310 : Nat) = 415310) ∧ False) ∨ ((((415311 : Nat) = 415311) ∧ False) ∨ ((((415312 : Nat) = 415312) ∧ False) ∨ ((((415313 : Nat) = 415313) ∧ False) ∨ ((((415314 : Nat) = 415314) ∧ False) ∨ ((((415315 : Nat) = 415315) ∧ False) ∨ ((((415316 : Nat) = 415316) ∧ False) ∨ ((((415317 : Nat) = 415317) ∧ False) ∨ ((((415318 : Nat) = 415318) ∧ False) ∨ ((((415319 : Nat) = 415319) ∧ False) ∨ ((((415320 : Nat) = 415320) ∧ False) ∨ ((((415321 : Nat) = 415321) ∧ False) ∨ ((((415322 : Nat) = 415322) ∧ False) ∨ ((((415323 : Nat) = 415323) ∧ False) ∨ ((((415324 : Nat) = 415324) ∧ False) ∨ ((((415325 : Nat) = 415325) ∧ False) ∨ ((((415326 : Nat) = 415326) ∧ False) ∨ ((((415327 : Nat) = 415327) ∧ False) ∨ ((((415328 : Nat) = 415328) ∧ False) ∨ ((((415329 : Nat) = 415329) ∧ False) ∨ ((((415330 : Nat) = 415330) ∧ False) ∨ ((((415331 : Nat) = 415331) ∧ False) ∨ ((((415332 : Nat) = 415332) ∧ False) ∨ (((415333 : Nat) = 415333) ∧ False))))))))))))))))))))))))))))))))))) :
    (Function.Surjective (g.comp f)) := by
  sorry

end FateCurriculum
