import Mathlib

namespace FateCurriculum

/-- FATE-M #3, curriculum variant 17/200; tier 1: direct_target. -/
theorem fate_m_003_v017 {G H K : Type*} [Group G] [Group H] [Group K]
    (f : G →* H) (g : H →* K) (hf : Function.Surjective f) (hg : Function.Surjective g)
    (curriculum_target : (Function.Surjective (g.comp f)))
    (curriculum_context_001 : ((101701 : Nat) = 101701))
    (curriculum_context_002 : ((101702 : Nat) = 101702))
    (curriculum_context_003 : ((101703 : Nat) = 101703))
    (curriculum_context_004 : ((101704 : Nat) = 101704))
    (curriculum_context_005 : ((101705 : Nat) = 101705))
    (curriculum_context_006 : ((101706 : Nat) = 101706))
    (curriculum_context_007 : ((101707 : Nat) = 101707))
    (curriculum_context_008 : ((101708 : Nat) = 101708))
    (curriculum_context_009 : ((101709 : Nat) = 101709))
    (curriculum_context_010 : ((101710 : Nat) = 101710))
    (curriculum_context_011 : ((101711 : Nat) = 101711))
    (curriculum_context_012 : ((101712 : Nat) = 101712))
    (curriculum_context_013 : ((101713 : Nat) = 101713))
    (curriculum_context_014 : ((101714 : Nat) = 101714))
    (curriculum_context_015 : ((101715 : Nat) = 101715))
    (curriculum_context_016 : ((101716 : Nat) = 101716)) :
    (Function.Surjective (g.comp f)) := by
  sorry

end FateCurriculum
