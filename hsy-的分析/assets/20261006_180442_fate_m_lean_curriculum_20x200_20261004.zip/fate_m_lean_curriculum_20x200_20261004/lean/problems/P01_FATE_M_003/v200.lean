import Mathlib

namespace FateCurriculum

/-- FATE-M #3, curriculum variant 200/200; tier 6: unscaffolded. -/
theorem fate_m_003_v200 {G H K : Type*} [Group G] [Group H] [Group K]
    (f : G →* H) (g : H →* K) (hf : Function.Surjective f) (hg : Function.Surjective g) :
    ((Function.Surjective (g.comp f)) ∧ (((620001 : Nat) = 620001) ∧ (((620002 : Nat) = 620002) ∧ (((620003 : Nat) = 620003) ∧ (((620004 : Nat) = 620004) ∧ (((620005 : Nat) = 620005) ∧ (((620006 : Nat) = 620006) ∧ (((620007 : Nat) = 620007) ∧ (((620008 : Nat) = 620008) ∧ (((620009 : Nat) = 620009) ∧ (((620010 : Nat) = 620010) ∧ (((620011 : Nat) = 620011) ∧ (((620012 : Nat) = 620012) ∧ (((620013 : Nat) = 620013) ∧ (((620014 : Nat) = 620014) ∧ (((620015 : Nat) = 620015) ∧ (((620016 : Nat) = 620016) ∧ (((620017 : Nat) = 620017) ∧ (((620018 : Nat) = 620018) ∧ (((620019 : Nat) = 620019) ∧ (((620020 : Nat) = 620020) ∧ (((620021 : Nat) = 620021) ∧ (((620022 : Nat) = 620022) ∧ (((620023 : Nat) = 620023) ∧ ((620024 : Nat) = 620024))))))))))))))))))))))))) := by
  sorry

end FateCurriculum
