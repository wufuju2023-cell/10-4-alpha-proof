import Mathlib

namespace FateCurriculum

/-- FATE-M #3, curriculum variant 196/200; tier 6: unscaffolded. -/
theorem fate_m_003_v196 {G H K : Type*} [Group G] [Group H] [Group K]
    (f : G →* H) (g : H →* K) (hf : Function.Surjective f) (hg : Function.Surjective g) :
    ((Function.Surjective (g.comp f)) ∧ (((619601 : Nat) = 619601) ∧ (((619602 : Nat) = 619602) ∧ (((619603 : Nat) = 619603) ∧ (((619604 : Nat) = 619604) ∧ (((619605 : Nat) = 619605) ∧ (((619606 : Nat) = 619606) ∧ (((619607 : Nat) = 619607) ∧ (((619608 : Nat) = 619608) ∧ (((619609 : Nat) = 619609) ∧ (((619610 : Nat) = 619610) ∧ (((619611 : Nat) = 619611) ∧ (((619612 : Nat) = 619612) ∧ (((619613 : Nat) = 619613) ∧ (((619614 : Nat) = 619614) ∧ (((619615 : Nat) = 619615) ∧ (((619616 : Nat) = 619616) ∧ (((619617 : Nat) = 619617) ∧ (((619618 : Nat) = 619618) ∧ (((619619 : Nat) = 619619) ∧ ((619620 : Nat) = 619620))))))))))))))))))))) := by
  sorry

end FateCurriculum
