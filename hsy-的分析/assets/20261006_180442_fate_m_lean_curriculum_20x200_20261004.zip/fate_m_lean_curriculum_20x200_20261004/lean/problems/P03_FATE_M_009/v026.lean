import Mathlib

namespace FateCurriculum

/-- FATE-M #9, curriculum variant 26/200; tier 1: direct_target. -/
theorem fate_m_009_v026 {G H : Type*} [Group G] [Group H] {f : G →* H} {a : G}
    (h : orderOf (f a) = 0)
    (curriculum_target : (orderOf a = 0))
    (curriculum_context_001 : ((102601 : Nat) = 102601))
    (curriculum_context_002 : ((102602 : Nat) = 102602))
    (curriculum_context_003 : ((102603 : Nat) = 102603))
    (curriculum_context_004 : ((102604 : Nat) = 102604))
    (curriculum_context_005 : ((102605 : Nat) = 102605))
    (curriculum_context_006 : ((102606 : Nat) = 102606))
    (curriculum_context_007 : ((102607 : Nat) = 102607))
    (curriculum_context_008 : ((102608 : Nat) = 102608))
    (curriculum_context_009 : ((102609 : Nat) = 102609))
    (curriculum_context_010 : ((102610 : Nat) = 102610))
    (curriculum_context_011 : ((102611 : Nat) = 102611))
    (curriculum_context_012 : ((102612 : Nat) = 102612))
    (curriculum_context_013 : ((102613 : Nat) = 102613))
    (curriculum_context_014 : ((102614 : Nat) = 102614))
    (curriculum_context_015 : ((102615 : Nat) = 102615))
    (curriculum_context_016 : ((102616 : Nat) = 102616))
    (curriculum_context_017 : ((102617 : Nat) = 102617))
    (curriculum_context_018 : ((102618 : Nat) = 102618))
    (curriculum_context_019 : ((102619 : Nat) = 102619))
    (curriculum_context_020 : ((102620 : Nat) = 102620))
    (curriculum_context_021 : ((102621 : Nat) = 102621))
    (curriculum_context_022 : ((102622 : Nat) = 102622))
    (curriculum_context_023 : ((102623 : Nat) = 102623))
    (curriculum_context_024 : ((102624 : Nat) = 102624))
    (curriculum_context_025 : ((102625 : Nat) = 102625)) :
    (orderOf a = 0) := by
  sorry

end FateCurriculum
