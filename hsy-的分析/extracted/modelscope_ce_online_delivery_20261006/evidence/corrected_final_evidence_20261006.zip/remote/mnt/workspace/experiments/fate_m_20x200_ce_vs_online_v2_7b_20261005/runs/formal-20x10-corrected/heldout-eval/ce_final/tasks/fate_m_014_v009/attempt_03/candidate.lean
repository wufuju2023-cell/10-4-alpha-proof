import Mathlib

namespace FateCurriculum

/-- FATE-M #14, curriculum variant 9/200; tier 1: direct_target. -/
theorem fate_m_014_v009 {R : Type*} [Ring R] [IsDomain R] (a : R) (n : ℕ)
    (eq : a ^ n = 0)
    (curriculum_target : (a = 0))
    (curriculum_context_001 : ((100901 : Nat) = 100901))
    (curriculum_context_002 : ((100902 : Nat) = 100902))
    (curriculum_context_003 : ((100903 : Nat) = 100903))
    (curriculum_context_004 : ((100904 : Nat) = 100904))
    (curriculum_context_005 : ((100905 : Nat) = 100905))
    (curriculum_context_006 : ((100906 : Nat) = 100906))
    (curriculum_context_007 : ((100907 : Nat) = 100907))
    (curriculum_context_008 : ((100908 : Nat) = 100908)) :
    (a = 0) := by
  assumption

end FateCurriculum
