import ReapRuntime

set_option reap.model "REAL-Prover"
set_option reap.num_premises 0
set_option reap.num_samples 64
set_option reap.max_tokens 512
set_option reap.temperature 150
set_option reap.max_steps 1
set_option reap.max_goals 64
set_option reap.visit_discount 990

namespace FateCurriculum

/-- FATE-M #51, curriculum variant 1/200; tier 1: direct_target. -/
theorem fate_m_051_v001 {G : Type*} [Group G] (a b : G) (h : (a * b) ^ 2 = a ^ 2 * b ^ 2)
    (curriculum_target : (a * b = b * a)) :
    (a * b = b * a) := by
  reapTrainingMCTS

end FateCurriculum
