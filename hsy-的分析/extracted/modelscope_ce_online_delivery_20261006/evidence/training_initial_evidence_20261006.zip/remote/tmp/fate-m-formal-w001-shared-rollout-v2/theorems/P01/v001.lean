import ReapRuntime

set_option reap.model "REAL-Prover"
set_option reap.num_premises 0
set_option reap.num_samples 64
set_option reap.max_tokens 512
set_option reap.temperature 150
set_option reap.max_steps 1
set_option reap.max_goals 64
set_option reap.visit_discount 990

namespace FateCurriculum

/-- FATE-M #3, curriculum variant 1/200; tier 1: direct_target. -/
theorem fate_m_003_v001 {G H K : Type*} [Group G] [Group H] [Group K]
    (f : G →* H) (g : H →* K) (hf : Function.Surjective f) (hg : Function.Surjective g)
    (curriculum_target : (Function.Surjective (g.comp f))) :
    (Function.Surjective (g.comp f)) := by
  reapTrainingMCTS

end FateCurriculum
