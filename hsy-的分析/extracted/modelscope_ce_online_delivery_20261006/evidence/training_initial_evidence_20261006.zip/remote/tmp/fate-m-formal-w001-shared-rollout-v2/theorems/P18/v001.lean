import ReapRuntime

set_option reap.model "REAL-Prover"
set_option reap.num_premises 0
set_option reap.num_samples 64
set_option reap.max_tokens 512
set_option reap.temperature 150
set_option reap.max_steps 1
set_option reap.max_goals 64
set_option reap.visit_discount 990

namespace FateCurriculum

/-- FATE-M #67, curriculum variant 1/200; tier 1: direct_target. -/
theorem fate_m_067_v001 {G H : Type*} [Group G] [Group H] (φ : G →* H)
    (g k : G) (hgk : g = k⁻¹)
    (curriculum_target : (φ g = (φ k)⁻¹)) :
    (φ g = (φ k)⁻¹) := by
  reapTrainingMCTS

end FateCurriculum
