import ReapRuntime

set_option reap.model "REAL-Prover"
set_option reap.num_premises 0
set_option reap.num_samples 64
set_option reap.max_tokens 512
set_option reap.temperature 150
set_option reap.max_steps 1
set_option reap.max_goals 64
set_option reap.visit_discount 990

open ComplexConjugate

namespace FateCurriculum

/-- FATE-M #35, curriculum variant 1/200; tier 1: direct_target. -/
theorem fate_m_035_v001 (curriculum_target : ({z : ℂ | conj z = z} = {z : ℂ | ∃ (x : ℝ), z = x})) :
    ({z : ℂ | conj z = z} = {z : ℂ | ∃ (x : ℝ), z = x}) := by
  reapTrainingMCTS

end FateCurriculum
