import ReapRuntime

set_option reap.model "REAL-Prover"
set_option reap.num_premises 0
set_option reap.num_samples 64
set_option reap.max_tokens 512
set_option reap.temperature 150
set_option reap.max_steps 1
set_option reap.max_goals 64
set_option reap.visit_discount 990

namespace FateCurriculum

/-- FATE-M #61, curriculum variant 1/200; tier 1: direct_target. -/
theorem fate_m_061_v001 {G : Type*} [Group G]
    (M : Subgroup G) [hM : M.Normal] (N : Subgroup G) [hN: N.Normal]
    (curriculum_target : ((M ⊓ N).Normal)) :
    ((M ⊓ N).Normal) := by
  reapTrainingMCTS

end FateCurriculum
