import ReapRuntime

set_option reap.model "REAL-Prover"
set_option reap.num_premises 0
set_option reap.num_samples 64
set_option reap.max_tokens 512
set_option reap.temperature 150
set_option reap.max_steps 1
set_option reap.max_goals 64
set_option reap.visit_discount 990

namespace FateCurriculum

/-- FATE-M #15, curriculum variant 1/200; tier 1: direct_target. -/
theorem fate_m_015_v001 {R : Type*} [Ring R] {x y z : R} (hx : x ≠ 0) (hy : x * y = 1)
    (hz : z * x = 1)
    (curriculum_target : (y = z)) :
    (y = z) := by
  reapTrainingMCTS

end FateCurriculum
