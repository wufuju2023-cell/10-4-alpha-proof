import ReapRuntime

set_option reap.model "REAL-Prover"
set_option reap.num_premises 0
set_option reap.num_samples 64
set_option reap.max_tokens 512
set_option reap.temperature 150
set_option reap.max_steps 1
set_option reap.max_goals 64
set_option reap.visit_discount 990

open Pointwise

namespace FateCurriculum

/-- FATE-M #76, curriculum variant 1/200; tier 1: direct_target. -/
theorem fate_m_076_v001 {G : Type*} [Group G] (H : Subgroup G) (a b : G)
    (curriculum_target : ((a • (H : Set G)) ∩ (b • (H : Set G)) ≠ ∅ →
    QuotientGroup.mk (s := H) a = QuotientGroup.mk (s := H) b)) :
    ((a • (H : Set G)) ∩ (b • (H : Set G)) ≠ ∅ →
    QuotientGroup.mk (s := H) a = QuotientGroup.mk (s := H) b) := by
  reapTrainingMCTS

end FateCurriculum
