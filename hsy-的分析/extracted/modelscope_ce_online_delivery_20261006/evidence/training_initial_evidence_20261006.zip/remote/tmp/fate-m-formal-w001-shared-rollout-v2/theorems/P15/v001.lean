import ReapRuntime

set_option reap.model "REAL-Prover"
set_option reap.num_premises 0
set_option reap.num_samples 64
set_option reap.max_tokens 512
set_option reap.temperature 150
set_option reap.max_steps 1
set_option reap.max_goals 64
set_option reap.visit_discount 990

namespace FateCurriculum

/-- FATE-M #64, curriculum variant 1/200; tier 1: direct_target. -/
theorem fate_m_064_v001 {G : Type*} [Group G] (g h : G)
    (curriculum_target : (∃! x, g * x = h ∧ ∃! x, x * g = h)) :
    (∃! x, g * x = h ∧ ∃! x, x * g = h) := by
  reapTrainingMCTS

end FateCurriculum
